﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class Productos
    {
        private int _id_Producto;
        private string _descripcion;
        private decimal _precio_Compra;
        private decimal _precio_Venta;
        private string _gravado;

        public int Id_Producto { get => _id_Producto; set => _id_Producto = value; }
        public string Descripcion { get => _descripcion; set => _descripcion = value; }
        public decimal Precio_Compra { get => _precio_Compra; set => _precio_Compra = value; }
        public decimal Precio_Venta { get => _precio_Venta; set => _precio_Venta = value; }
        public string Gravado { get => _gravado; set => _gravado = value; }

        public Productos(int id_producto, string descripcion, decimal precio_Compra, decimal precio_Venta, string gravado)
        {
            _id_Producto= id_producto;
            _descripcion = descripcion;
            _precio_Compra= precio_Compra;
            _precio_Venta= precio_Venta;
            _gravado= gravado;  
        }

        public Productos()
        {
            _id_Producto = 0;
            _descripcion = string.Empty;
            _precio_Compra = 0;
            _precio_Venta = 0;
            _gravado = string.Empty;
        }
    }

}