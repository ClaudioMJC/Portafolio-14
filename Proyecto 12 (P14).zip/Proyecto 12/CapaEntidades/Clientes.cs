﻿using System;

namespace CapaEntidades
{
    public class Clientes
    {
        
        private int id_Cliente;
        private string nombre;
        private string telefono;
        private string direccion;
        public bool existe;
        //constructores
        public Clientes()
        {
            Id_Cliente = 0;
            Nombre = "";
            Telefono = "";
            Direccion = "";
            existe = false;
        }
        public Clientes(int id_Cliente, string nombre, string telefono, string direccion, bool existe)
        {
            this.Id_Cliente = id_Cliente;
            this.Nombre = nombre;
            this.Telefono = telefono;
            this.existe = existe;
        }

        public int Id_Cliente { get => id_Cliente; set => id_Cliente = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public bool Existe { get => existe; set => existe = value; }

    }
}
