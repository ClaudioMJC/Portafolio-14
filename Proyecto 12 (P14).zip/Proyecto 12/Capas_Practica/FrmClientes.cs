﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using capa02_Logica;
using Capa03_AccesoDatos;
using CapaEntidades;


namespace Capas_Practica
{

    public partial class FrmClientes : Form
    {   //PASO NÚMERO 9 PRESENTACIÓN 21
        FrmBuscarC formularioBuscar;
        //PASO 9 FIN

        public FrmClientes()
        {
            InitializeComponent();
        }

        //crea un objeto con los datos ingresados en las casillas de texto
        public Clientes generaCliente()
        {
            Clientes unCliente = new Clientes();
            unCliente.Nombre = txtNombre.Text;
            unCliente.Telefono = txtTelefono.Text;
            unCliente.Direccion = txtDireccion.Text;

            return unCliente;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Clientes UnCliente = new Clientes();
            Bl_Clientes logicaCliente = new Bl_Clientes(Configuracion.getConnectionString);
            int resultado;
            try
            {
                if (string.IsNullOrEmpty(txtNombre.Text) | string.IsNullOrEmpty(txtTelefono.Text) | string.IsNullOrEmpty(txtDireccion.Text))
                {
                    MessageBox.Show("ooops! Faltan datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    UnCliente = generaCliente();
                    resultado = logicaCliente.LlamarMetodoInsertar(UnCliente);
                    LimpiarCasillas();
                    MessageBox.Show("operacion fue exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LimpiarCasillas()
        {
            txtIdCliente.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txtNombre.Focus();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        //paso 4 presentación 21
        private void FrmClientes_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaClientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //paso 5 presentación 21  //SE CONFIGURA EL BOTON DE MANERA DIFERENTE EN AMBOS PASOS
        //PASA 10 PRESENTACION 21
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //FrmBuscarClientes frm = new FrmBuscarClientes();
            //frm.Show();
            formularioBuscar = new FrmBuscarC();
            //se especifica que se quiere usar el evento Aceptar
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        } //fin_btnBuscar_Click


        //Cargar los datos  presentacion 21 tercer paso
        public void CargarListaClientes(string condicion = "")
        {
            Bl_Clientes logicaBuscar = new Bl_Clientes(Configuracion.getConnectionString);
            List<Clientes> listarClientes;
            try
            {
                listarClientes = logicaBuscar.llamarListaClientes(condicion);
                if (listarClientes.Count > 0)
                {
                    grdClientes.DataSource = listarClientes;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //paso 11 presentación 21
        private void Aceptar(Object id, EventArgs e)
        {
            try
            {
                int idCliente = (int)id;
                if (idCliente != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    CargarClientes(idCliente);
                }
                else
                {
                    LimpiarCasillas();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin aceptar

        //Paso 17 presentación 21
        private void CargarClientes(int id)
        {
            Clientes cliente = new Clientes();
            Bl_Clientes traerCliente = new Bl_Clientes(Configuracion.getConnectionString);
            try
            {
                cliente = traerCliente.obtenerCliente(id);
                if (cliente != null)
                {
                    txtIdCliente.Text = cliente.Id_Cliente.ToString();
                    txtNombre.Text = cliente.Nombre;
                    txtTelefono.Text = cliente.Telefono;
                    txtDireccion.Text = cliente.Direccion;

                }
                else
                {
                    MessageBox.Show("El cliente no se encuentra en la base de datos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaClientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin cargar cliente

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCasillas();
        }

    }//public partial class end
}
