﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using capa02_Logica;
using CapaEntidades;

namespace Capas_Practica
{
    public partial class FrmProductos : Form
    {

        public FrmProductos()
        {
            InitializeComponent();
        }

        //crea un objeto con los datos ingresados en las casillas de texto
        public Productos generaProducto()
        {
            Productos producto = new Productos();
            producto.Descripcion = txtDescripcion.Text;
            producto.Precio_Compra = decimal.TryParse(txtPrecioCompra.Text, out decimal precio) ? precio : 0;
            producto.Precio_Venta = decimal.TryParse(txtPrecioVenta.Text, out decimal precio1) ? precio1 : 0;
            producto.Gravado = textGravado.Text;
            return producto;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Productos producto = new Productos();
            Bl_Productos logicaProducto = new Bl_Productos(Configuracion.getConnectionString);
            int resultado;
            try
            {
                if (string.IsNullOrEmpty(txtDescripcion.Text) | string.IsNullOrEmpty(txtPrecioVenta.Text) | string.IsNullOrEmpty(txtPrecioCompra.Text))
                {
                    MessageBox.Show("Faltan datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    producto = generaProducto();
                    resultado = logicaProducto.LlamarMetodoInsertar(producto);

                    LimpiarCasillas();
                    MessageBox.Show("operacion fue exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LimpiarCasillas()
        {
            txtIdCliente.Text = string.Empty;
            txtDescripcion.Text = string.Empty;
            txtPrecioVenta.Text = string.Empty;
            txtPrecioCompra.Text = string.Empty;
            textGravado.Text = string.Empty;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FrmClientes_Load(object sender, EventArgs e)
        {

        }
    }
}
