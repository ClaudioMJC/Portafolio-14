﻿using System;
using System.Data.SqlClient;
using CapaEntidades;
namespace Capa03_AccesoDatos
{
    public class DaProductos
    {       //atributos
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DaProductos(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        public int Insertar(Productos producto)
        {
            int id = 0;
            //Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            //Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO PRODUCTOS (DESCRIPCION, PRECIOCOMPRA,PRECIOVENTA,GRAVADO)"+
            "VALUES( @DESCRIPCION, @PRECIOCOMPRA, @PRECIOVENTA, @GRAVADO) SELECT SCOPE_IDENTITY()";
            comando.Parameters.AddWithValue("@DESCRIPCION", producto.Descripcion);
            comando.Parameters.AddWithValue("@PRECIOCOMPRA", producto.Precio_Compra);
            comando.Parameters.AddWithValue("@PRECIOVENTA", producto.Precio_Venta);
            comando.Parameters.AddWithValue("@GRAVADO", producto.Gravado);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }  //Fin de insertar
    }
}
